1. Removing a digital signature is possible with firmware until june 2019 and lower, if you have firmware July 2019 and above, use our image for SD card 
2.Upload the file signature.tar.gz through the upgarde function of the asic firmware or massively through btctool (upgrade function), an error will occur, it is normal
3.Download the our firmware from our website through the upgrade function or massively through btctool (upgrade function)
4. Go to ASIC via IP (only numbers, for example 192.168.1.2) and press ctrl + f5 to reset the cache if you see the old firmware


1.Снятие цифровой подписи возможно с прошивок до июня 2019 года включительно, если у вас прошивка июль 2019 года и выше используйте наш образ для SD карты для прошивки асика
2.Загрузите файл signature.tar.gz через функцию upgarde или массово через btctool (функция upagrade), вылетит ошибка
3.Загрузите прошивку с нашего сайта через функцию upgrade или массово через btctool (функция upgrade)
4.Зайдите по на асик через IP (только цифры, например 192.168.1.2) и нажмите ctrl+f5 чтобы сбросить кэш если вы видите старую прошивку