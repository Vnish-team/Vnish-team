1. unlock SSH is working will all types of the Bitmain firmware. 

If you have problem with unlocking ssh try to put the folder unlock_ssh to the disc c:
and run files without administration rights

2. You need edit settings.cfg
	-Set network IPNETWORK parameter. If you have 192.168.88.* - set IPNETWORK=192.168.88 (192.168.1.*, set IPNETWORK=192.168.1)
	-Set scan range IPSTART and IPEND. If you want scan from 192.168.1.2 to 192.168.1.40 - set IPSTART=2 IPEND=40.
	-Set Antminer web password ASICWEBPASS=your_password. (Default: root)
	-Set Antminer ssh password ASICSSHPASS=your_password. (Default: admin)
3. Scan network and unlock(if possible) selected range with "1.unlock_ssh.bat" script.
4. Wait 2-5 min for Antminers boot up.
5. RUN replace.bat" script.
6. Flash any firmware with BTCTools, etc..


1. РАЗБЛОКИРОВКА SSH работает на всех версиях прошивок BITMAIN 
 
Если при разблокировки SSH вылетает ошибка то проверьте разархивировали ли вы папку unlock_ssh на диск C: и запустите ее без прав Администратора

2. Вам нужно отредактировать settings.cfg
	-Установите параметр IPNETWORK сети. Если у вас есть 192.168.88. * - установите IPNETWORK=192.168.88 (если у вас 192.168.1. *, установите IPNETWORK=192.168.1)
	-Установить диапазон сканирования IPSTART и IPEND. Если вы хотите сканировать с 192.168.1.2 по 192.168.1.40 - установите IPSTART=2, IPEND=40.
	-Установите веб-пароль Antminer ASICWEBPASS=ваш_пароль (По умолчанию: root)
	-Установить пароль ssh Antminer ASICSSHPASS=ваш_пароль (По умолчанию: admin)
3. Сканировать и разблокировать(если возможно) найденные устройства с помощью скрипта "1.unlock_ssh.bat".
4. ПОДОЖДИТЕ 2-5 минут для загрузки Antminers.
5. ЗАПУСТИТЬ ФАЙЛ REPLACE.BAT 
6. Далее просто заливаете прошивку PROMINER через функцию upgrade асика или массово через btctool (функция upgrade)
